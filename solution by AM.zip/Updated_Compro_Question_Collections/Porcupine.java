package Updated_Compro_Question_Collections;

public class Porcupine {
    public static void main(String[] args){
        System.out.println(findPorcupineNumber(1000));
    }
    public static int findPorcupineNumber(int n){
        int p = -1, np = -1;
        do {
            n++;
            if(isPrime(n) && n % 10 == 9 ){
                p = n;
                while (p > -1 && np == -1){
                    n++;
                    if (isPrime(n)){
                        np = n;
                        if (np % 10 != 9){
                            p = -1; np = -1;
                        }
                    }
                }
            }
        }while (p == -1 && np == -1);
        return p;
    }
    public static boolean isPrime(int n)
    {
        if (n <= 1) return false;
        for (int i = 2; i <= n / 2; i++) {
            if (n % i == 0) return false;
        }
        return true;
    }
}
