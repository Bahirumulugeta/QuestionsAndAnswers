package Updated_Compro_Question_Collections;

public class NextPerfectSquare {
    public static void main(String[] args){
        System.out.println(isperfectSquarae(19));
    }
    public static int isperfectSquarae(int n){
        int i = 1; int squared = 0;
        while(squared <= n) {
            squared = i*i; i++;
        }
        return squared;
    }
}
