package Updated_Compro_Question_Collections;

public class RepsEqual {
    public static void main(String[] args){
        int[] a =  {3, 2, 0, 5, 3, 4};
        int n =  32053;
        System.out.println(repsEqual(a,n));
    }
    public static int repsEqual(int[ ] a, int n){
        int reps = 1;
        for (int i = a.length-1; i >= 0 && reps == 1; i--){
            int lastD = n % 10;
            if (lastD != a[i])
                reps = 0;
            n = n / 10;
        }
        return reps;
    }
}
