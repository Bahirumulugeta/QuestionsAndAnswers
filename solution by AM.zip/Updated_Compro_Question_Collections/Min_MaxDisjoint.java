package Updated_Compro_Question_Collections;

public class Min_MaxDisjoint {
    public static void main(String[] args){
        int[][] a = {{18, -1, 3, 4, 0},
                        {9, 0, 5, 9},
                          {0, 5, 18, 0, 9},
                        {7, 7, 7, 7},
                        {},
                        {1, 2},
                        {1}};
        for (int [] i : a)
            System.out.println(isMinMaxD(i));
    }
    public static int isMinMaxD(int[] a){
        int max = Integer.MIN_VALUE, min = Integer.MAX_VALUE, minI = 0, maxI= 0, isMinMax = 1;
        if (a.length < 3)
            isMinMax = 0;
        for (int i = 0; i < a.length && isMinMax == 1; i ++){
            if (min > a[i]){
                min = a[i];
                minI ++;
            }
            if (max < a[i]){
                max = a[i];
                maxI ++;
            }
        }
        int count = 0;
        if ((maxI == minI + 1) || (maxI == minI -1))
            isMinMax = 0;
        for (int i = 0; i < a.length && isMinMax == 1; i++){
            if (min == a[i] || max == a[i])
                count++;
            if (count > 2)
                isMinMax = 0;
        }
       return isMinMax;
    }
}
