package Updated_Compro_Question_Collections;

public class Isolated {
    public static void main(String[] args){
        int [] a = {7,2,3,8,9,14,24,28,34,58,63,162};
        for (int i : a)
            System.out.println(isIsolated(i));
    }
    public static int isIsolated(long n){
        int isIsolated = 1;
        if (n < 0 || n > 2097151)
            isIsolated = -1;
        long square = n*n;
        long cube = n*n*n;
        long cubeD = 0, squareD = 0;

        while (cube > 0 && isIsolated == 1){
            cubeD = cube % 10;
            cube = cube / 10;
            while (square > 0 && isIsolated == 1){
                squareD = square % 10;
                square = square / 10;
                if (squareD == cubeD)
                    isIsolated = 0;
            }
        }
        return isIsolated;
    }
}
