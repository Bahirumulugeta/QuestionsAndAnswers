package Updated_Compro_Question_Collections;

public class Cluster {
    public static void main(String[] args) {
        int[][] a = {{0, 0, 0, 2, 0, 2, 0, 2, 0, 0},
                {18},
                {},
                {-5, -5, -5, -5, -5},
                {1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1},
                {8, 8, 6, 6, -2, -2, -2}};
        for (int[] i : a) {
            int[] b = clusterCompression(i);
            System.out.print("{ ");
            for (int j = 0; j < b.length; j++)
                System.out.print(b[j] + " ");
            System.out.print("}");
            System.out.println();
        }
    }

    public static int[] clusterCompression(int[] a) {

        int index = 0;
        int[] temp = new int[a.length];
        for (int i = 0; i < a.length; i++) {
            if (i == 0) {
                temp[index] = a[i];
                index++;
            } else {
                    if(a[i] != a[i-1]){
                    temp[index] = a[i];
                    index++;
                }
            }
        }
        int[] result = new int[index];
        for (int i = 0; i < index; i++) {
            result[i] = temp[i];
        }
        return result;
    }

}
