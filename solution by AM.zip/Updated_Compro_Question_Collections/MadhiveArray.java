package Updated_Compro_Question_Collections;

public class MadhiveArray {
    public static void main(String[] args) {
        int[][] a = {{2, 1, 1},
                {2, 1, 1, 4, -1, -1},
                {6, 2, 4, 2, 2, 2, 1, 5, 0, 0},
                {18, 9, 10, 6, 6, 6},
                {-6, -3, -3, 8, -5, -4},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, -2, -1},
                {3, 1, 2, 3, 0}};
        for (int[] i : a)
            System.out.println(isMadArray(i));
    }

    public static int isMadArray(int[] a) {
        int isMad = 1;
        int isMadhiveLen = 0; // the length must be n(n-1)/2 for some n
        for (int i = 1; i < a.length && isMadhiveLen == 0; i++)
            if (a.length == (i * (i - 1) / 2))
                isMadhiveLen = 1;
        if (isMadhiveLen == 0)
            return 0;
        int firstV = a[0], startE = 1, round = 1, endE = startE + round;
        while (isMad == 1 && endE < a.length) {
            int sum = 0;
            for (int i = startE; i <= endE; i++) {
                sum += a[i];
            }
            if (sum != firstV)
                isMad = 0;
            startE = endE + 1;
            round++;
            endE = startE + round;
        }
        return isMad;
    }
}
