package Updated_Compro_Question_Collections;

public class FilterArray {
    public static void main(String[] ars) {
        int a[] = {0, 9, 12, 18, -6};
        int n = 11;
        int[] temp = filterArray(a, n);
        for (int i : temp)
            System.out.print(i + " ");
    }

    public static int[] filterArray(int[] a, int n) {
		int digitIndex = 0, indexCount = 0;
		int[] temp = new int[a.length];

		while(n>0){
			int lastDigit = n % 2;
			if(lastDigit == 1){
				temp[indexCount] = digitIndex;
				indexCount++;
			}
			digitIndex++;
			n = n / 2;
		}
		int result[] = new int[indexCount];
 		for(int i = 0; i < indexCount; i ++){
			if(temp[i] > a.length-1)
				return null;
			result[i] = a[temp[i]];
		}
		return result;
//        int index = 0, count = 0;
//        while (n > 0) {
//            if (n % 2 == 1){
//            	count++;
//			}
//            n = n /2;
//        }
//        int[] temp = new int[count];
//        if(count > a.length) return null;
//        int i = 0;
//        while(n > 0){
//        	if(n % 2 == 1){
//        		temp[i] = a[index];
//        		i++;
//			}
//        	index++;
//        	n = n / 2;
//		}
//        return temp;
    }
}
