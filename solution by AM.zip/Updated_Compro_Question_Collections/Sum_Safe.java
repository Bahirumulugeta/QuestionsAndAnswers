package Updated_Compro_Question_Collections;

public class Sum_Safe {
    public static void main(String[] args){
        int[] a = {5,-2,1};
        System.out.println(isSumSafe(a));
    }
    public static int isSumSafe(int[ ]a) {
        int sum = 0, issumSafe = 1;
        for (int i = 0; i < a.length; i++)
            sum += a[i];
        for (int i = 0; i < a.length && issumSafe == 1; i++){
            if (sum == a[i])
                issumSafe = 0;
        }
        return issumSafe;
    }
}
