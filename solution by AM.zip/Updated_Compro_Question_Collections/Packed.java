package Updated_Compro_Question_Collections;

public class Packed {
    public static void main(String [] args){
        int[][] a = {{1,2, 2, 1},
                {2, 2, 1, 2, 2},
                {4, 4, 4, 4, 1, 2, 2, 3, 3, 3},
                {7, 7, 7, 7, 7, 7, 7,1},
                {7, 7, 7, 7, 1, 7, 7, 7},
                {7, 7, 7, 7, 7, 7, 7},
                {},
                {1, 2,2, 1},
                {2, 1, 1} ,
                {-3, -3, -3} ,
                {0, 2, 2} ,
                {2, 1, 2}};
        for (int[] i: a){
            System.out.println(isPacked(i));
        }
    }
    public static int isPacked(int[] a){
        int i = 0;
        while ( i < a.length) {
            int count = 0;
            if(a[i] < 0) return 0;
            for (int j = i; j < a.length ; j++) {
                if (a[i] == a[j])  count++;
                else{
                    for(int k = j; k < a.length;k++){
                        if(a[k] == a[i]) return 0;
                    }
                }
            }
            if (count != a[i]) return 0;
            i+=count;
        }
        return 1;
    }
}
