package Updated_Compro_Question_Collections;

public class Solve10 {
    public static void main(String[] args){
        int[] b = solve10();
        for (int i : b)
            System.out.println(i);
    }
    public static int[] solve10(){
        int solve = 0, x = 1, y = 1;
        int a[] =  new int[2];
        for (int i = 1; i < 10 && solve == 0; i++){
            for (int j = 1; j < 10 && solve == 0; j++){
                if (factorial(i) + factorial(j) == factorial(10)){
                    x = i; y = j;
                    solve = 1;
                }
            }
        }
        if (solve == 0)
            x = y = 0;
        a[0] = x; a[1] = y;
        return a;
    }
    public static int factorial( int n){
        int fact = 1;
        for (int i = 1; i <= n; i++)
            fact *= i;
        return fact;
    }
}
