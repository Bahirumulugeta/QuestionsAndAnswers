package Updated_Compro_Question_Collections;

public class GetExponent {
    public static void main(String[] args) {
        System.out.println(getExponent(-250, 5));
    }

    public static int getExponent(int n, int p) {
        int max = 0, i = 0;
        if (p < 2)
            return -1;
        do {
            if (n % p == 0){
                n = n / p;
                i++;
            }
            else
                max = 1;
        } while (max == 0);
        return i;
    }
}
