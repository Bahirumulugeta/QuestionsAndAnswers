package Updated_Compro_Question_Collections;

public class N_Unique {
    public static void main(String[] args){
        int[] a = {7, 3, 3, 2, 4};
        System.out.println(isNUnique(a,11));
    }
    public static int isNUnique(int[ ] a, int n){
        int count = 0;
        for (int i = 0; i < a.length && count < 2; i++){
            for (int j = i+1; j < a.length && count < 2; j++){
                if (a[j] + a[i] == n)
                    count ++;
            }
        }
        if (count == 1)
            return 1;
        return 0;
    }
}
