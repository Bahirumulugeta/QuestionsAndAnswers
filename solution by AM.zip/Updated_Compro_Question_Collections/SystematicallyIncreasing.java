package Updated_Compro_Question_Collections;

public class SystematicallyIncreasing {
    public static void main(String[] args) {
        int[][] a = {{1},
                {1, 2, 1, 2, 3},
                {1, 1, 2,1,2,3},
                {1, 2, 1, 2, 1, 2},
                {1, 2, 3, 1, 2, 1},
                {1, 1, 2, 3}};
        for(int i[] : a)
            System.out.println(isSystematicallyIncreasing(i));
    }

    public static int isSystematicallyIncreasing(int[] a) {
        int x = 0;
        for (int i = 0; i < a.length && x < a.length; i++) {
            for (int j = 0; j <= i; j++) {
                if (a[x] != j + 1) return 0;
                x++;
            }
        }
        return 1;
    }
}
