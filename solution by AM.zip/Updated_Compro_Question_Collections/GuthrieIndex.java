package Updated_Compro_Question_Collections;

public class GuthrieIndex {
    public static void main(String[] args){
        int[] a= {1,2,3,4,42,7};
        for (int i : a)
            System.out.println(guthrieIndex(i));
    }
    public static int guthrieIndex(int n){
        int index = 0;
        while (n > 0 && n != 1){
            if (n % 2 == 0)
                n = n/2;
            else
                n = n*3 + 1;
            index ++;
        }
        return index;
    }
}
