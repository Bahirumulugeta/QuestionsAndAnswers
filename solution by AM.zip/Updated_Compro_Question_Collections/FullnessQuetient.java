package Updated_Compro_Question_Collections;

public class FullnessQuetient {
    public static void main(String[] args){
        System.out.println(fullnessQuotient(9));
    }
    public static int fullnessQuotient(int n){
        if (n < 1)
            return -1;
        int count = 0;
        for (int i = 2; i <= 9; i++){
            int num = n;
            int check = 0;
            while (num > 0 ) {
                if (num % i == 0)
                    check ++;
                num = num / i;
            }
            if (check == 0)
                count ++;
        }
        return count;
    }
}
