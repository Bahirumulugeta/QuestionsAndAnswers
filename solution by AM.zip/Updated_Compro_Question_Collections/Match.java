package Updated_Compro_Question_Collections;

public class Match {
    public static void main(String[] args){
        int[] a = {1,2,3,-5,-5,2,3,18};
        int[] p = {4, -1, 3};
        System.out.println(isMAtch(a,p));
    }
    public static int isMAtch(int[] a , int[] p){
        int isMatch = 1, lowerIndx = 0, uperIndx = 0;
        boolean isNegtv = false;
        for (int i = 0; i < p.length && isMatch == 1; i++){
            isNegtv = (p[i] < 0);
            if (p[i] < 0)
                p[i] *= -1;
            uperIndx = lowerIndx + p[i];

            for (int j = lowerIndx; j < uperIndx && isMatch == 1; j++){
                if (isNegtv){
                    if (a[j] > 0)
                        isMatch = 0;
                }
                else{
                    if (a[j] < 0)
                        isMatch = 0;
                }
            }
            lowerIndx = uperIndx;
        }
        return isMatch;
    }
}
