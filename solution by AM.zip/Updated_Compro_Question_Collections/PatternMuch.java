package Updated_Compro_Question_Collections;

public class PatternMuch {
    public static void main(String[] args) {
        int[] A = {1, 2, 3, -5, -5, 2, 3, 18}, P = {3, -2, 3};
        System.out.println(matches(A,P));
    }

    public static int matches(int[] a, int[] p) {
        int sum = 0;
        for (int i = 0; i < p.length; i++) {
            if (p[i] < 0) p[i] *= -1;
            sum += p[i];
        }
        if (a.length != sum) return 0;

        int start = 0;
        for (int i = 0; i < p.length; i++) {
            int sign = 1;
            if (p[i] < 0) {
                p[i] *= -p[i];
                sign *= -1;
            }
            for (int j = start; j < start + p[i]; j++) {
                if (sign == -1 ){
                    if(a[j] > 0) return 0;
                }
                else{
                    if(a[j] < 0) return 0;
                }
            }
            start += p[i];
        }
        return 1;
    }
}
