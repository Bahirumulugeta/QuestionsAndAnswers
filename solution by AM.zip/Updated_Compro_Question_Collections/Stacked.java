package Updated_Compro_Question_Collections;

public class Stacked {
    public static void main(String[] args){
        int[] a = {1,3,6,7,10,20,15};
        for (int i : a)
            System.out.println(isStacked(i));
    }
    public static int isStacked(int n){
        int isStacked = 0, sum = 0;
        for (int i = 1; i < n && sum <= n; i++){
            sum += i;
            if (sum == n)
                isStacked = 1;
        }
        return isStacked;
    }
}
