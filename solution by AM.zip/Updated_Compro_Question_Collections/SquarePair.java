package Updated_Compro_Question_Collections;

public class SquarePair {
    public static void main(String[] args){
        int[ ] a = {11, 5, 4, 20};
        System.out.println(countSquarePairs(a));
    }
    public static int countSquarePairs(int[ ] a){
        int temp, count = 0;
        for (int i = 0; i < a.length; i++){
            if(a[i] > 0){
                for (int j = 0; j < a.length; j++){
                    if (a[i] < a[j] && a[j] > 0){
                        temp = a[i] + a[j];
                        if (isSquared(temp) == 1)
                            count++;
                    }
                }
            }
        }
        return count;
    }
    public static int isSquared(int n){
        int isSqueared = 0;
        if(n == 0 || n == 1) return 1;
        for (int i = 1; i <= n/2 && isSqueared == 0; i++){
            if (i * i == n)
                isSqueared = 1;
        }
        return isSqueared;
    }
}
