package Updated_Compro_Question_Collections;

public class SumFactor {
    public static void main(String[] args){
        int a[][] = {{3, 0, 2, -5, 0},
                {9, -3, -3, -1, -1},
                {1},
                {0, 0, 0}};
        for (int[] i : a)
            System.out.println(sumFactor(i));
    }
    public static int sumFactor(int[ ] a){
        int sum = 0, sumCount = 0;
        for (int i = 0; i < a.length; i++)
            sum += a[i];
        for (int i = 0; i < a.length; i++){
            if (a[i] == sum)
                sumCount ++;
        }
        return sumCount;
    }
}
