package Updated_Compro_Question_Collections;

public class Smallest {
    public static void main(String[] args){
        int[] a = {4,5,6,7};
        for(int i : a)
            System.out.println(isSmallest(i));

    }
    public static int isSmallest(int n){
        int j = 2; // first number to check
        while(true){
            int k = 1;
            for(int i = 1; i <= n; i ++){
                if(containsTwo(i*j) == 0)
                    break;
                k++;
            }
           if(k - 1 == n) return j;
           j++;
        }
    }
    public static int containsTwo(int n){
        while(n > 1){
            if(n % 10 == 2) return 1;
            n = n / 10;
        }
        return 0;
    }
}
