package Updated_Compro_Question_Collections;

public class SequentiallyBounded {
    public static void main(String[] args){
        int[][] a = {{0, 1},
                      {-1, 2},
                       {},
                       {5, 5, 5, 5},
                       {5, 5, 5, 2, 5}};
        for (int[] i : a)
            System.out.println(isSequentiallyBounded(i));
    }
    public static int isSequentiallyBounded(int[] a){
        int curr = 0, prev = 0, i = 0, count = 0;
        int isSequential = 1;
        while (i < a.length && isSequential == 1){
            curr = a[i];
            if (curr <= 1) isSequential = 0;
            if (i == 0) prev = curr;

            if (prev > curr) isSequential = 0;
            else if (prev == curr){
                count ++;
                i++;
                if (count >= prev)
                    isSequential = 0;
            }
            else
                count = 0;
            prev = curr;
        }
        return isSequential;
    }
}
