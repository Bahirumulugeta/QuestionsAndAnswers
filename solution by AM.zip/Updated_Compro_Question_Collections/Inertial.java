package Updated_Compro_Question_Collections;

public class Inertial {
    public static void main(String[] args) {
        int[][] testCase = {{1},
                {2},
                {1, 2, 3, 4},
                {1, 1, 1, 1, 1, 1, 2},
                {2, 12, 4, 6, 8, 11},
                {2, 12, 12, 4, 6, 8, 11},
                {-2, -4, -6, -8, -11},
                {2, 3, 5, 7},
                {2, 4, 6, 8, 10}};
        for (int[] i : testCase)
            System.out.println(inertial2(i));
    }

    //    public static int isInertial(int[] a){
//        int isInertial = 1;
//
//        int[] oddValues = new int[a.length];
//        int oddindex = -1;
//        int[] evenValues = new int[a.length];
//        int evenindex = -1;
//        int maxValue = 0;
//
//        for (int i = 0; i < a.length; i++) {
//            // get the max value
//            if(a[i] > maxValue) {
//                maxValue = a[i];
//            }
//            // check for odd and even;
//            if(a[i] %2 == 0) {
//                evenindex++;
//                evenValues[evenindex] = a[i];
//            }
//            else {
//                oddindex++;
//                oddValues[oddindex] = a[i];
//            }
//        }
//
//        //a- check if contains at least one odd value
//        if (oddindex < 0)
//            return 0;
//        //b- check  if the maximum value in the array is even
//        if (maxValue % 2 != 0)
//            return 0;
//        int oddvalue = 0, evenvalue = 0;
//
//        //c- check if every odd value is greater than every even value that is not the maximum value.
//        for (int i = 0; i <= oddindex && isInertial == 1; i++) {
//            oddvalue = oddValues[i];
//            for (int j = 0; j <= evenindex && isInertial == 1; j++){
//                evenvalue = evenValues[j];
//
//                if (evenvalue != maxValue) {
//                    if (evenvalue > oddvalue)
//                        isInertial = 0; //exit theloop
//                }
//            }
//        }
//        return isInertial;
//    }
    public static int inertial2(int[] a) {
        int hasOdd = 0, max = Integer.MIN_VALUE;
        for (int i = 0; i < a.length; i++) {
            if (max < a[i]) max = a[i];
            if (a[i] % 2 == 1) hasOdd = 1;
        }
        if (max % 2 == 1 || hasOdd == 0) return 0;

        for (int i = 0; i < a.length; i++) {
            if (a[i] % 2 == 1) {
                for (int j = 0; j < a.length; j++) {
                    if(a[j] % 2 == 0 && a[i] < a[j] &&a[j] != max)
                        return 0;
                }
            }
        }
        return 1;
    }
}
