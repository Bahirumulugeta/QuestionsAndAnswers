package Updated_Compro_Question_Collections;

public class PrimeFactors {
    public static void main(String[] args){
        int n = 20;
        int[] a = encodeNumber(n);
        for(int i = 0; i < a.length;i++)
            System.out.println(a[i]);
    }
    public static int[ ] encodeNumber(int n){
        if( n < 2) return null;
        int[] temp = new int[(int)Math.sqrt(n)];
        int index = 0;
        for (int i = 2; i <= n/2; i++) {
            while(n % i == 0){
                temp[index] = i;
                n = n / i;
                index++;
            }
        }
        if(n > 2) {
            temp[index] = n;
            index++;
        }
        int[] result = new int[index];
        for (int i = 0; i < index; i++) {
            result[i] = temp[i];
        }
        return result;
    }
}
