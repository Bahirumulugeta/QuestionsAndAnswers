package Updated_Compro_Question_Collections;

public class OddHeavy {
    public static void main(String[] args){
        int[][] a = {{1},
                  {2},
                   {1, 1, 1, 1, 1, 1},
                   {2, 4, 6, 8, 11},
                   {-2, -4, -6, -8, -11}};
        for (int[] i : a){
            System.out.println(isOddHeavy(i));
        }
    }
    public static int isOddHeavy(int[] a){
        boolean hasOdd = false;
        for (int i = 0; i < a.length; i ++){

            if (a[i] % 2 ==1){
                hasOdd = true;
                for (int j = 0; j < a.length; j ++){
                    if (a[i] < a[j] && a[j] % 2 == 0)
                        return 0;
                }
            }
        }
        if (!hasOdd)
            return 0;
        return 1;
    }
}
