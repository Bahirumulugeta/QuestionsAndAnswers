package Updated_Compro_Question_Collections;

import org.omg.Messaging.SYNC_WITH_TRANSPORT;

public class StantonMeasure {
    public static void main(String[] args){
        int[][] a = {{1} ,
                    {0} ,
                    {3, 1, 1, 4}};
        for (int[] i : a)
            System.out.println(stantonMeasure(i));
    }
    public static int stantonMeasure(int[ ] a){
        int count1 = 0;
        for (int i = 0; i < a.length; i++){
            if (a[i] == 1) count1 ++;
        }
        int countn = 0;
        for (int i = 0; i < a.length;i++){
            if(a[i] == count1) countn ++;
        }
        return countn;
    }
}
