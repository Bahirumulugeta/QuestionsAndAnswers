package Updated_Compro_Question_Collections;

public class PrimeCount {
    public static void main(String[] args) {
        System.out.println(primeCount(-10,6));
    }
    public static int primeCount(int start, int end){
        int count = 0;
        for (int i = start; i <= end; i++){
            int check = 0;
            if (i > 1){
                for (int j = 2; j <= i/2 && check == 0; j++ ){
                    if (i % j == 0)
                        check++;
                }
                if (check == 0)
                    count ++;
            }
        }
        return count;
    }
}