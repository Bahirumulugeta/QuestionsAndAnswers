package Updated_Compro_Question_Collections;

public class GuthrieSequence {
    public static void main(String[] args) {
        int[][] a = {{8, 4, 2, 1},
                {8, 17, 4, 1},
                {8, 4, 1},
                {8, 4, 2}};
        for (int[] i : a)
            System.out.println(isGuthrieSequence(i));
    }

    public static int isGuthrieSequence(int[] a) {
        int gtr = 1;
        if (a[a.length - 1] != 1)
            return 0;
        for (int i = 0; i < a.length-1 && gtr == 1; i++) {
            if (a[i] % 2 == 0 && a[i+1] != a[i] / 2) {
                gtr = 0;
            } else if (a[i] % 2 == 1 && a[i+1] != (3 * a[i] + 1)) {
                gtr = 0;
            }
        }
        return gtr;
    }
}
