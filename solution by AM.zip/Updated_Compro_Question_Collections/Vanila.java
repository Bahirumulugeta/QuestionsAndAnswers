package Updated_Compro_Question_Collections;

public class Vanila {
    public static void main(String[] args){
        int[][] a = {{1},
                {11, 22, 13, 34, 125},
                {9, 999, 99999, -9999},
                { }};
        for(int[] i : a)
            System.out.println(isVanilla(i));
    }
    public static int isVanilla(int[ ] a){
        int isVanila = 1;
        int digit = 0;
        for(int i = 0; i < a.length && isVanila == 1; i ++){
            if(a[i] < 0) a[i] = a[i]*-1;
            if(i == 0)
                digit = a[i] % 10;
            while(a[i] > 0 && isVanila == 1){
                int digit2 = a[i] % 10;
                a[i] = a[i] / 10;
                if(digit != digit2) isVanila = 0;
            }
        }
        return isVanila;
    }
}
