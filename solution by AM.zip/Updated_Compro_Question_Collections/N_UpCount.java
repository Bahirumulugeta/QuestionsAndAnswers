package Updated_Compro_Question_Collections;

public class N_UpCount {
    public static void main(String[] args){
        int[] a = {2,3,1,-6,8,-3,-1,2};
        System.out.println(nUpCount(a,5));
    }
    public static int nUpCount(int[] a, int n){
        int parSum = 0;
        int preParSum = 0;
        int count = 0;
        for (int i = 0; i < a.length; i++){
            parSum += a[i];
            if (parSum >= n && preParSum < n)
                count++;
            preParSum = parSum;
        }
        return count;
    }
}
