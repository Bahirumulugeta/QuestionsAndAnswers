package Updated_Compro_Question_Collections;

public class Centered_15 {
    public static void main(String[] args){
        int[][] a = {{3, 2, 10, 4, 1, 6, 9},
                {2, 10, 4, 1, 6, 9},
                {3, 2, 10, 4, 1, 6},
                {1,1,8, 3, 1, 1},
                {9, 15, 6},
                {1, 1, 2, 2, 1, 1},
                {1, 1, 15 -1,-1}};
        for (int i[] : a)
            System.out.println(isCentered15(i));
    }
    public static int isCentered15(int[ ] a){
        int iscentered15 = 0;
        for (int i = 0; i < a.length && iscentered15 == 0; i++){
            int sum = 0;
            for (int j = i; j < a.length && sum < 15; j ++){
                sum += a[j];
                if (sum == 15 && i == (a.length -1) - j)
                    iscentered15 = 1;
            }
        }
        return iscentered15;
    }
}
