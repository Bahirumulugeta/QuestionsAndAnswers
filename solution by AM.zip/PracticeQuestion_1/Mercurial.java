package PracticeQuestion_1;

public class Mercurial {
    public static void main(String[] args){
        int[][] a = {{1, 2, 10, 3, 15, 1, 2, 2},
                {5, 2, 10, 3, 15, 1, 2, 2} ,
                {1, 2, 10, 3, 15, 16, 2, 2},
                {3, 2, 18, 1, 0, 3, -11, 1, 3},
                {2, 3, 1, 1, 18} ,
                {8, 2, 1, 1, 18, 3, 5} ,
                {3, 3, 3, 3, 3, 3} ,
                {1} ,
                {}};
        for (int[] i : a)
            System.out.println(isMercurial(i));
    }
    public static int isMercurial(int[ ] a){
        int index;
        int exL = 0, three = 0;
        for (int i = 0; i < a.length; i++) {
            if(exL == 0 && a[i] == 1) exL = 1;
            else if(exL == 1 && a[i] == 3) three = 1;
            else if(exL == 1 && three == 1 && a[i] == 1) return 0;
        }
         return 1;
    }
}
