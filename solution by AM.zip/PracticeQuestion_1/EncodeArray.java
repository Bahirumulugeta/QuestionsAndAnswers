package PracticeQuestion_1;

public class EncodeArray {
    public static void main(String[] args){
        int a = 999;
        int[] b = encode(a);
        for(int i = 0; i < b.length; i ++)
             System.out.print(b[i]);
    }
    public static int[] encode(int n){
        int sign = 1;
        if(n < 0)
            sign = -1;
        int temp = n*sign;
        int size = 0;
        while(temp > 0){
            int lastD = temp % 10;
            size = size + lastD + 1;
            temp = temp/10;
        }
        if(sign == -1)
            ++size;
        int[] encode = new int[size];
        if(sign == -1) encode[0] = -1;
        n = n*sign;
        while(n > 0){
            int lastD = n % 10;
            n = n /10;
            encode[size-1] = 1;
            size -= lastD+1;
        }
        return encode;
    }
}
