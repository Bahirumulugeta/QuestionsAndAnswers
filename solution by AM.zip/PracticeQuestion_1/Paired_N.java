package PracticeQuestion_1;

public class Paired_N {
    public static void main(String[] args){
        int[] a = {1,4,1};
        System.out.println(isPairedN(a,5));
    }
    public static int isPairedN(int[ ] a, int n){
        if (a.length-1 + a.length -2 < n || n < 0)
            return 0;
        int isPN = 0;
        for (int i = 0; i< a.length && isPN == 0; i++){
            for (int j = i+1; j < a.length && isPN == 0; j++)
                if (a[i] + a[j] == n && i + j == n)
                    isPN = 1;
        }
        return isPN;
    }
}
