package PracticeQuestion_1;

public class DecodeArray {
    public static void main(String[] args){
        int[][] a= {{1},
                    {0, 1},{1,0,0,0,1,1},
                    {-1, 0, 1},
                    {0, 1, 1, 1, 1, 1, 0, 1},
                    {0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1}};
        for (int[] i : a)
            System.out.println(decodeArray(i));
    }
    public static int decodeArray(int[] a){
        int sign = 1;
        int ten = 1, decodN = 0, zeroC = 0;
        for (int i = 0; i < a.length; i++){
            // check if number is -ve
            if (i == 0)
                if (a[i] < 0)
                    sign = a[i];
                // count the consecutive zeros
            if (a[i] == 0)
                zeroC ++;
            else if (a[i] == 1){
                    decodN = decodN * 10 + zeroC;
                    zeroC = 0;
                }
        }
        decodN = decodN * sign;
        return decodN;
    }
}
