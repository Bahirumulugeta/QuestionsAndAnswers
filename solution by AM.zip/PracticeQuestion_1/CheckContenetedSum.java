package PracticeQuestion_1;

public class CheckContenetedSum {
    public static void main(String[] args) {
        System.out.println(checkConcatenatedSum(13332, 4));
    }

    public static int checkConcatenatedSum(int n, int catlen) {
        int concSum = 0;
        int temp = n;
        while (n > 0) {
            int rem = n % 10;
            n = n / 10;
            int digit = 0;
            for (int i = 1; i <= catlen; i++) {
                digit = digit * 10 + rem;
            }
            concSum += digit;
        }
        if (concSum == temp)
            return 1;
        return 0;
    }
}
