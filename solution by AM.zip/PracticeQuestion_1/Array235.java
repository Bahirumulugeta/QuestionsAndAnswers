package PracticeQuestion_1;

public class Array235 {
    public static void main(String[] args){
        int[][] a = {{2, 3, 5, 7, 11},
        {2, 3, 6, 7, 11} ,
        {2, 3, 4, 5, 6, 7, 8, 9, 10} ,
        {2, 4, 8, 16, 32} ,
        {3, 9, 27, 7, 1, 1, 1, 1, 1},
        {7, 11, 77, 49},
        {2} ,
        {} ,
        {7, 2, 7, 2, 7, 2, 7, 2, 3, 7, 7}};
        for (int[] i : a){
            System.out.println(is235Array(i));
        }
    }
    public static int is235Array(int[] a){
        int c = 0;
        for (int i = 0; i < a.length; i ++){
            if (a[i] % 2 == 0)
                c++;
            if (a[i] % 3 == 0)
                c++;
            if (a[i] % 5 == 0)
                c++;
            if (a[i] % 2 != 0 && a[i] % 3 != 0 && a[i] % 5 != 0)
                c++;
        }

        if (c == a.length)
            return 1;
        return 0;
    }
}
