package PracticeQuestion_1;

public class Array121 {
    public static void main(String[] args) {
        int[][] a = {{1, 2, 1},
                {1, 1, 2, 2, 2, 1, 1},
                {1, 1, 2, 2, 2, 1, 1, 1},
                {1, 1, 1, 2, 2, 2, 1, 1},
                {1, 1, 1, 2, 2, 2, 1, 1, 1, 3},
                {2, 2, 2, 1, 1, 1, 2, 2, 2, 1, 1, 1},
                {1, 1, 1, 2, 2, 2, 1, 1, 1, 2, 2},
                {1, 1, 1}};
        for (int[] i : a) {
            System.out.println(is121Array(i));
        }
    }

    public static int is121Array(int[] a) {
        if (a.length <= 2)
            return 0;
        // the beginning and the end must be 1
        if (a[0] != 1 || a[a.length - 1] != 1)
            return 0;
        //check for the elements are only 1 and 2
        boolean hastwo = false;
        int index1= 0, index2 = 0;
        if(a[a.length/2] != 2) return 0;

        for (int i = 0, j = a.length - 1; i < j ; i++, j--) {
            if (!(a[i] == 1 || a[i] == 2)) return 0;
            if (a[i] != a[j])  return 0;
            if(a[i] == 2) index1 = i;
            if(a[j] == 2) index2 = j;

            if(index1 > 0 && a[i] == 1 || index2 > 0 && a[j] == 1)
                return 0;
        }
        return 1;
    }
}
