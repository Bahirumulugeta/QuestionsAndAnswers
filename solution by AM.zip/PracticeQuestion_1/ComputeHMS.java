package PracticeQuestion_1;

public class ComputeHMS {
    public static void main(String[] args){
        int[] a = computeHMS(3650);
        System.out.print("{");
        for (int i = 0; i < a.length; i++)
            System.out.print(a[i] + ",");
        System.out.print("}");
    }
    public static int[] computeHMS(int second){
        int[] hms = new int[3];
        int hr, mn, sc;
//        hr = second / 3600;
//        second = second % 3600;
//        mn = second / 60;
//        second = second % 60;
//        sc = second;
//        hms[0] = hr;
//        hms[1] = mn;
//        hms[2] = sc;
        mn = second / 60;
        sc = second % 60;
        hr = mn / 60;
        mn = mn % 60;
        hms[0] = hr;
        hms[1] = mn;
        hms[2] = sc;
        return hms;
    }
}
