package PracticeQuestion_1;

public class HodderNumber {
    public static void main(String[] args){
        int[] a = {3, 7, 31, 127,10};
        for(int i : a)
            System.out.println(isHodder(i));
    }
    public static int isHodder(int n){
        if(n < 0)
            return 0;
        if(isPrime(n)){
            int isH = 1;
            for(int i = 1; i < n; i ++){
                isH *=2;
                if(isH -1 == n)
                    return 1;
            }
        }
        return 0;
    }
    public static boolean isPrime( int n){
        if ( n < 2)
            return false;
        for (int i = 2; i <= n/2; i++){
            if (n % i == 0)
                return false;
        }
        return true;
    }
}
