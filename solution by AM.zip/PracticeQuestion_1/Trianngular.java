package PracticeQuestion_1;

public class Trianngular {
    public static void main(String[] args){
            System.out.println(isTriangular(10));
    }
    public static int isTriangular(int n){
        int isT = 0, sum = 0;
        if (n < 1)
            return 0;
        for (int i = 1; i <= n && isT == 0 && sum <= n; i++){
            sum += i;
            if (sum == n)
                isT = 1;
        }
        return isT;
    }
}
