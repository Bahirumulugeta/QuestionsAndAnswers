package PracticeQuestion_1;

public class PairWiseSum {
    public static void main(String[] args){
        int[] a = {2, 1, 18, -5, -5, -15, 0, 0, 1, -1};
        int[] ret = pairWise(a);
        for(int i = 0; i < ret.length; i++)
            System.out.println(ret[i]);
    }
    public static int[] pairWise(int[] a){
        if(a == null || a.length % 2 !=0 )
            return null;
        int[] result = new int[a.length/2];
        int index = 0;
        for(int i = 0; i < a.length; i += 2){
            result[index] = a[i]+ a[i+1];
            index ++;
        }
        return result;
    }
}
