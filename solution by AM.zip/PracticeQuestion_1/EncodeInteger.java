package PracticeQuestion_1;

public class EncodeInteger {
    public static void main(String[] args){
        int[][] a = {{0, -3, 0, -4, 0},
                    {-1, 5, 8, 17, 15},
                    {1, 5, 8, 17, 15},
                    {111, 115, 118, 127, 125},
                    {1, 1}};
        for (int[] i : a)
            System.out.println(decodeArray(i));
    }
    public static int decodeArray(int[] a){
        int digit, no = 0;
        if (a.length < 2)
            return 0;
        for (int i = 1; i < a.length; i++){
            digit = a[i-1] - a[i];
            if (digit < 0)
               no = no*10 + digit*-1;
            else
                no = no*10 +digit;
        }
        if (a[0] < 0)
            return no*-1;
        return no;
    }
}
