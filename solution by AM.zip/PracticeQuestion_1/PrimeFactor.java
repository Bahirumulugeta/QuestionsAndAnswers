package PracticeQuestion_1;

public class PrimeFactor {
    public static void main(String[] args){
        int[] b = encodeNumber(1200);
        for(int i =0 ; i < b.length;i++)
             System.out.println(b[i]);
    }
    public static int[] encodeNumber(int n) {
        if (n <= 1)
            return null;
        int size = (int) Math.sqrt(n);
        int[] a = new int[size];
        int c = 0;
        int temp = n / 2;
        for (int i = 2; i <= temp; i++) {
            if(isPrime(i)){
                while (n % i == 0) {
                    n = n / i;
                    a[c] = i;
                    c++;
                }
            }
        }
        if (n > 2) {
            a[c] = n;
            c++;
        }
        int[] ret = new int[c];
        for (int i = 0; i < c; i++)
            ret[i] = a[i];
        return ret;
    }
    public static boolean isPrime( int n){
        if ( n < 2)
            return false;
        for (int i = 2; i <= n/2; i++){
            if (n % i == 0)
                return false;
        }
        return true;
    }
}
