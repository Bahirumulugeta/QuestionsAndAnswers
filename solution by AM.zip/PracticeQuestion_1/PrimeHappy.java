package PracticeQuestion_1;

public class PrimeHappy {
    public static void main(String[] args){
        int[] a = {5,25,32,8,2};
        for (int i : a)
            System.out.println(isPrimeHappy(i));
    }
    private static int isPrimeHappy(int n){
        int c = 0;
        int sum = 0;
        for (int i = 1; i < n; i++){
            if (isPrime(i)){
                c++;
                sum = sum + i;
            }
        }
        if ( sum % n == 0 && c >= 1)
            return 1;
        return 0;
    }
    public static boolean isPrime( int n){
        if ( n < 2)
            return false;
        for (int i = 2; i <= n/2; i++){
            if (n % i == 0)
                return false;
        }
        return true;
    }
}
