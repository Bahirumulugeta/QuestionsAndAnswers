package PracticeQuestion_1;

public class LargestDifferenceOFEven {
    public static void main(String[] args){
        int[][] a = {{1, 3, 5, 9},
                {1, 18, 5, 7, 33},
                {2, 2, 2, 2},
                {1, 2, 1, 2, 1, 4, 1, 6, 4}};
        for(int[] i : a)
            System.out.println(largestD(i));
    }
    public static int largestD(int[] a){
        if(a.length < 2)
            return -1;
        int minE = Integer.MAX_VALUE, maxE= Integer.MIN_VALUE,c = 0;

        for(int i = 0; i < a.length; i++){
            if(a[i] % 2 == 0){
                c++;
                if(maxE < a[i])
                    maxE = a[i];
                if(minE > a[i])
                    minE = a[i];
            }
        }
        return (c >= 2) ? maxE-minE : -1;
    }
}
