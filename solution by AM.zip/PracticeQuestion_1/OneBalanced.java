package PracticeQuestion_1;

public class OneBalanced {
    public static void main(String[] args){
        int [][] a = {{1, 1, 1, 2, 3, -18, 45, 1},
                  {1, 1, 1, 2, 3, -18, 45, 1, 0},
                  {1, 1, 2, 3, 1, -18, 26, 1},
                  {},
                  {3, 4, 1, 1} ,
                   {1, 1, 3, 4},
                   {3, 3, 3, 3, 3, 3},
                   {1, 1, 1, 1, 1, 1}};
        for (int [] i : a){
            System.out.println(isOneBalanced(i));
        }
    }
    public static int isOneBalanced(int[] a){
        int oneBC = 0, oneEC = 0, seq = 0, nonOneC = 0;
        int oneSeq = 0;
        if (a.length == 0 )
            return 1;
        for (int i = 0 ; i < a.length; i++){
            if (a[i] == 1 && seq == 0)
                oneBC ++;
            else if (a[i] == 1 && seq > 0)
                oneEC ++;
            else{
                nonOneC++;
                seq++;
            }
        }
        if (seq == 1 && ((oneBC + oneEC) == nonOneC))
            return 1;
        return 0;
    }
}
