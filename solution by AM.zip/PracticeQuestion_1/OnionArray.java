package PracticeQuestion_1;

public class OnionArray {
    public static void main(String[] args){
        int[][] a = {{1, 2, 19, 4, 5},
                     {1, 2, 3, 4, 15},
                     {1, 3, 9, 8},
                     {2},
                     {},
                     {-2, 5, 0, 5, 12}};
        for(int[] i : a)
            System.out.println(isOnion(i));
    }
    public static int isOnion(int[ ] a){
        for(int i = 0, j = a.length-1; i < j;i++, j --){
            if(a[i] + a[j] > 10)
                return 0;
        }
        return 1;
    }
}
