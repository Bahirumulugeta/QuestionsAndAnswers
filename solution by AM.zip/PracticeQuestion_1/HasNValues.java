package PracticeQuestion_1;

public class HasNValues {
    public static void main(String[] args){
        int[] a = {1, 2, 3, 4, 5, 6, 7, 8 ,9, 10};
        System.out.println(hasNValues(a,20));
    }
    public static int hasNValues(int[] a, int n){
        int index = 0;
        int[] temp = new int[a.length];
        for(int i = 0; i< a.length; i++){
            if(i == 0) temp[index++] = a[i];
            else{
                int found = 0;
                for(int j = 0 ; j < index; j++){
                    if(a[i] == temp[j])
                        found = 1;
                }
                if(found == 0)
                    temp[index++] = a[i];
            }
        }
        return (index == n)? 1 : 0;
    }
}
