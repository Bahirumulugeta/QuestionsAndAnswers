package PracticeQuestion_1;

public class AllValuesTheSame {
    public static void main(String[] args) {
        int[][] a = {{1, 1, 1, 1},
                {83, 83, 83},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {1, -2343456, 1, -2343456},
                {0, 0, 0, 0, -1},
                {432123456},
                {-432123456},
                {}};
        for(int[] i : a)
            System.out.println(allValuesTheSame(i));
    }

    public static int allValuesTheSame(int[] a) {
        if (a.length < 1) return 0;
        for (int i = 0; i < a.length - 1; i++) {
            if (a[i] != a[i + 1]) return 0;
        }
        return 1;
    }
}
