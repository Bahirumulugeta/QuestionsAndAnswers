package PracticeQuestion_1;

public class ZeroPlentiful {
    public static void main(String[] args){
        int[][] a = {{0, 0, 0, 0, 0},
                    {1, 2, 0, 0, 0, 0, 2, -18, 0, 0, 0,0},
                    {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0},
                    {1, 2, 3, 4},
                    {1, 0, 0, 0, 2, 0, 0, 0, 0},
                    {0}};
        for (int[] i : a){
            System.out.println(isZeroPlentiful(i));
        }
    }
    public static int isZeroPlentiful(int[ ] a){
        int isZero = 1;
        int count = 0;
        int zerocount = 0;

        for (int i = 0; i < a.length; i++) {
            if(a[i] == 0) zerocount++;
            else{
                if(zerocount >= 4){
                    count++;
                }else{
                    if(zerocount > 0) return 0;
                }
                zerocount = 0;
            }
            if(i == a.length-1){
                if(zerocount >= 4) count ++;
                else return 0;
            }
        }
        return count;
    }
}
