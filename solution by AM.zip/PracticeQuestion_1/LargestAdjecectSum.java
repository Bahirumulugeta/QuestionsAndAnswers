package PracticeQuestion_1;

public class LargestAdjecectSum {
    public static void main(String[] args){
        int[][] a= {{1, 2, 3, 4},
                    {18, -12, 9, -10},
                    {1,1,1,1,1,1,1,1,1},
                    {1,1,1,1,1,2,1,1,1}};
        for (int[] i : a)
            System.out.println(largestAdjacentSum(i));
    }
    public static int largestAdjacentSum(int[ ] a){
       int max = Integer.MIN_VALUE;
       if (a.length< 2 )
           return 0;
       for (int i = 0; i< a.length - 1; i++){
          if (max < a[i] + a[i+1])
              max = a[i] + a[i+1];
       }
       return max;
    }
}
