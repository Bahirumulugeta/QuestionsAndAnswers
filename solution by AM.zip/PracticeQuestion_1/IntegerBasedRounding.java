package PracticeQuestion_1;

public class IntegerBasedRounding {
    public static void main(String[] args) {
        int[] a = {1, 2, 3, 4, 5, 6};
        int n = 2;
        doIntegerBasedRounding(a, n);
    }

    public static void doIntegerBasedRounding(int[] a, int n) {
        if (n <= 0) {
            System.out.println("N must be GT 0");
            return;
        }

        for (int i = 0; i < a.length; i++) {
            int val = 0, j = 1;
            while (val < a[i]) {
                val = n * j;
                int prev = (j - 1) * n;
                if (a[i] - prev < val - a[i]) a[i] = prev;
                else if (a[i] - prev > val - a[i]) a[i] = val;
                else a[i] = val;
                j++;
            }
        }
        for (int i = 0; i < a.length; i++)
            System.out.println(a[i]);
    }
}
