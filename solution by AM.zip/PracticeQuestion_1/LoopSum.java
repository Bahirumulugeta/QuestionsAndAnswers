package PracticeQuestion_1;

public class LoopSum {
    public static void main(String[] args){
        int[] a= {-1, 2, -1};
//                {36, 28},
//                {4},
//                {3, 2, 1, 1, 5, 6},
//                {3, 7, 23, 13, 107, -99, 97, 81}};
            System.out.println(loopSum(a,7));
    }
    public static int loopSum(int[] a , int n){
        if(a.length < 1 || n <= 0) return 0;
        int sum = 0;
        for(int i =0 ; i < n; i ++){
            int index = i % a.length;
            sum += a[index];
        }
        return sum;
    }
}
