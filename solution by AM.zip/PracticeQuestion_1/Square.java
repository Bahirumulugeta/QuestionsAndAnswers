package PracticeQuestion_1;

public class Square {
    public static void main(String[] args){
        int[] a = {4,25,-4,8,0};
        for(int i : a)
            System.out.println(isSquare(i));
    }
    public static int isSquare(int n){
        if (n < 0) return 0;
        if(n == 0 || n == 1) return 1;
        for(int i = 1; i <= n/2; i++)
            if(i*i == n)
                return 1;
        return 0;
    }
}
