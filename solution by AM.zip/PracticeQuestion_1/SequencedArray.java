package PracticeQuestion_1;

public class SequencedArray {
    public static void main(String[] args){
        int[] a = {1, 3, 4, 2, 5};
        System.out.println(isSequencedArray(a,1,5));
    }
    public static int isSequencedArray(int[ ] a, int m, int n){

        int isSequnced = 1;
        int current = 0;
        for (int i = 0; i < a.length && isSequnced==1; i++){
            current = a[i];
            if (i == 0)
                if (current != m)
                    isSequnced = 0;
            if (i == a.length - 1)
                if (current != n)
                    isSequnced = 0;
            if (current < m || current > n)
                isSequnced = 0;
            if (i > 0)
                if (current < a[i - 1]) isSequnced = 0;
            if (i < (a.length - 1))
                if (current != a[i + 1])
                    if (a[i + 1] != current + 1)
                        isSequnced = 0;
        }

        return isSequnced;
    }
}
