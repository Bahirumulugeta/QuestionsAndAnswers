package PracticeQuestion_1;

public class CubePowerful {
    public static void main(String[] args){
        int[] a = {153,370,371,407,87,0,-81};
        for (int i = 0; i< a.length; i++)
            System.out.println(isCubePowerful(a[i]));
    }
    public static int isCubePowerful(int n){
        int rem, sum = 0, temp = n;
        if (temp <= 0)
            return 0;
        while (temp > 0){
            rem = temp % 10;
            sum = sum + (rem*rem*rem);
            temp /= 10;
        }
        if (sum == n)
            return 1;
        else
            return 0;
    }
}
