package PracticeQuestion_1;

public class Vesuvian {
    public static void main(String[] args){
        int[] a = {50,65,85,23};
        for(int i : a)
             System.out.println(isVesuvian(i));
    }
    public static int isVesuvian(int n){

        int m = (int)Math.sqrt(n);
        int isV = 0, sC = 0;
        for (int i = 1; i <= m && isV == 0; i++){
            for (int j = 1; j <= m && isV == 0;j++)
                if ((i * i) + (j * j) == n){
                    sC ++;
                }
            if (sC == 2)
                isV = 1;
        }
        return isV;
    }
}
