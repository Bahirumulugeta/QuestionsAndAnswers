package PracticeQuestion_1;

import java.util.Scanner;

public class LargestPrimeFactor {
    public static void main(String[] args){
        int n;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Number");
        n = sc.nextInt();
        int max = 2;
        for (int i = 2; i <= n; i++){
            if (n % i == 0 && isPrime(i))
                if (max < i)
                    max = i;
        }
        System.out.println(max + " is the max prime factor"+ 6369/193);
    }
    public static boolean isPrime( int n){
        if ( n < 2)
            return false;
        for (int i = 2; i <= n/2; i++){
            if (n % i == 0)
                return false;
        }
        return true;
    }
}
