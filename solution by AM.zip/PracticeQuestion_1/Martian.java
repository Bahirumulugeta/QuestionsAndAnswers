package PracticeQuestion_1;

public class Martian {
    public static void main(String[] args){
        int[][] a = {{1, 3},
                {1, 2, 1, 2, 1, 2, 1, 2, 1},
                {1, 3, 2, 2, 1, 5, 1, 5},
                {1, 2, -18, -18, 1, 2},
                {},
                {1},
                {2}};
        for (int[] i : a){
            System.out.println(isMartian(i));
        }
    }
    public static int isMartian(int[ ] a){
        int count1 = 0, count2 = 0, isMartian = 1;
        for (int i = 0; i < a.length && isMartian == 1; i ++){
            if (a[i] == 1)
                count1 ++;
            else if (a[i] == 2)
                count2 ++;
            if ( i < a.length-1){
                if (a[i] == a[i+1]) {
                    isMartian = 0;
                }
            }
        }
        if (count1 > count2 && isMartian == 1)
            return 1;
        return 0;
    }
}
