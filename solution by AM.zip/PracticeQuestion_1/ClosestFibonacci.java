package PracticeQuestion_1;

public class ClosestFibonacci {
    public static void main(String[] args){
        int[] a = {34,13,33};
        for(int i : a)
            System.out.println(closestFib(i));
    }
    public static int closestFib(int n){
        if(n <= 1 ) return 0;
        int first = 1, second = 1, current = 0;
        while(current + first <= n){
            current = first + second;
            first = second;
            second = current;
        }
        return current;
    }
}
