package PracticeQuestion_1;

public class N_Primeable {
    public static void main(String[] args){
        int[] a = {5,15,27};
        System.out.println(isNPrimeable(a,2));
    }
    public static int isNPrimeable(int[ ] a, int n){
        int isNP = 1;
        for (int i = 0; i < a.length && isNP == 1; i++){
            if (!isPrime(a[i]+n))
                isNP = 0;
        }
        return isNP;
    }
    public static boolean isPrime( int n){
        if ( n < 2)
            return false;
        for (int i = 2; i <= n/2; i++){
            if (n % i == 0)
                return false;
        }
        return true;
    }
}
