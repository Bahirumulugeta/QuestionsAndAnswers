package PracticeQuestion_1;

public class DigitIncreasing {
    public static void main(String[] args){
        // must be revised, the output is not correct
        int[] a = {7,36,984,7404,13};
        for (int i = 0; i < a.length; i++)
            System.out.println(isDigitIncreasing(i));
    }
    public static int isDigitIncreasing(int n){

        int digitIn = 0;
        for (int i = 1; i <= 9 && digitIn == 0; i++){
            int sum = 0, digit = 0;
            while(sum <= n){
                digit =digit*10 + i;
                sum += digit;
            }
            if (digit == n)
                return 1;
        }
        return 0;
    }
}
