package PracticeQuestion_1;

public class FactorialPrime {
    public static void main(String[] args){
        int[] a= {2,3,7,8,11,721};
        for (int i : a){
            System.out.println(isFactorialPrime(i));
        }
    }
    public static int isFactorialPrime(int n){
        int ispf = 0; int fact =1;
        if (isPrime(n)){
            for (int i = 1; i < n && ispf == 0; i++){
                fact *= i;
                if (fact + 1 == n)
                    ispf = 1;
            }
        }
        return ispf;
    }
    public static boolean isPrime( int n){
        if ( n < 2)
            return false;
        for (int i = 2; i <= n/2; i++){
            if (n % i == 0)
                return false;
        }
        return true;
    }
//    public static int fact(int n){
//        int fact = 1;
////        if (n == 0 || n == 1)
////            return 1;
////        else
////            fact *= n*fact(n-1);
////        return fact;
//        for (int i = 1; i <= n ; i++)
//            fact *= i;
//        return fact;
//    }
}
