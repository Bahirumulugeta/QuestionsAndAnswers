package PracticeQuestion_1;

public class SameNumberOfFactors {
    public static void main(String[] args){
        System.out.println(sameNumberOfFactors(-6,21));
        System.out.println(sameNumberOfFactors(6,21));
        System.out.println(sameNumberOfFactors(8,12));
        System.out.println(sameNumberOfFactors(23,97));
        System.out.println(sameNumberOfFactors(0,1));
        System.out.println(sameNumberOfFactors(0,0));
    }
    public static int sameNumberOfFactors(int n1, int n2){
        if(n1 < 0 || n2 < 0) return -1;
        if(n1 == n2 ) return 1;
        if(n1 == 0 || n2 == 0) return 0;
        int factN1= 0, factN2 =0;
        int larg = (n1 > n2)? n1 : n2;
        for(int i = 1; i <= larg; i ++){
            if(n1 % i == 0) factN1++;
            if(n2 % i == 0) factN2++;
        }
        return (factN1 == factN2)? 1 : 0;
    }
}
