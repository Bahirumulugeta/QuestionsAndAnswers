package PracticeQuestion_1;

public class Fibonacci {
    public static void main(String[] args){
        System.out.println(isFibinacci(4));
    }
    public static int isFibinacci(int n){
        int first = 1, second = 1, current = first + second;
        if (n < 0)
            return 0;
        if (n == 1)
            return 1;
        do {
            first = second;
            second = current;
            current = first + second;
            if (current == n)
                return 1;
        }while (current <= n );
        return 0;
    }
}
