package PracticeQuestion_1;

public class Complete {
    public static void main(String[] args){
        int[][] a = {{36, -28},
                {36, 28},
                {4},
                {3, 2, 1, 1, 5, 6},
                {3, 7, 23, 13, 107, -99, 97, 81}};
        for(int[] i : a)
            System.out.println(isComplete(i));
    }
    public static int isComplete(int[] a){
        if(a== null || a.length == 0) return 0;
        int hasEven = 0, hasPs = 0, hasSum8 = 0;
        for(int i =0 ; i < a.length; i++){
            if(a[i] % 2 == 0) hasEven = 1;
            if(isSquare(a[i]) == 1) hasPs = 1;
            for(int j = 0 ; j < a.length && hasSum8 == 0; j ++)
                if(a[i] + a[j] == 8 && i != j)
                    hasSum8 = 1;
            if(hasEven == 1 && hasPs == 1 && hasSum8 == 1)
                return 1;
        }
        return 0;
    }
    public static int isSquare(int n){
        if (n < 0) return 0;
        if(n == 0 || n == 1) return 1;
        for(int i = 1; i <= n/2; i++)
            if(i*i == n)
                return 1;
        return 0;
    }
}
