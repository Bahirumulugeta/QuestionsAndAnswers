package Updated_CompPro_fromBack;

public class FillArray {
    public static void main(String[] args){
        int a[] = {1,2,3,5,9,12,-2,-1};
        int[] reterned = fill(a, 3, 10);
        if (reterned == null)
         return ;
        for (int i = 0; i < reterned.length; i++){
            System.out.println(reterned[i]);
        }
    }
    public static int[] fill(int[] arr, int k, int n){
        if (k < 1 || n < 1) return null;
        int[] arr2 = new int[n];
        for (int i = 0; i < arr2.length; i++){
            int index = i % k;
            arr2[i] = arr[index];
        }
        return arr2;
    }
}
