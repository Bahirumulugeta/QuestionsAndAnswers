package Updated_CompPro_fromBack;

public class BunkerArray {
    public static void main(String[] args){
        int[] a = { 6, 10,1,7};
        System.out.println(isBunker(a));
    }
    public static int isBunker(int[] a){
        boolean hasOne = false, hasPrime = false;
        for (int i = 0; i < a.length; i ++){
            if(isPrime(a[i]) == 1)
                hasPrime = true;
            if (a[i] == 1)
                hasOne = true;
        }
        if (hasPrime && !hasOne || !hasPrime && hasOne)
            return 0;
        return 1;
    }
    public static int isPrime( int n){
        if (n < 2)
            return 0;
        for (int i = 2; i <= n/2; i++){
            if ( n % i == 0){
                return 0;
            }
        }
        return 1;
    }
}
