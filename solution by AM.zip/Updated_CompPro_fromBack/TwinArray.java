package Updated_CompPro_fromBack;

public class TwinArray {
    public static void main(String[] args){
        int[][] a = {{13, 15, 8, 10, 27}, // 3 and 5 are twins and both are present
                    }; // 17 has a twin prime and it is missing in the array
        for(int[] i : a)
            System.out.println(isTwin(i));
    }
    public static int isTwin(int[] a){
        int isTwin = 1;
        for(int i = 0; i < a.length && isTwin == 1; i ++){
            if(isPrime(a[i]) == 1){
                if(isPrime(a[i]+2) == 1 || isPrime(a[i]-2) == 1){
                    int found = 0;
                    for(int j = 0; j < a.length && found == 0;j++){
                        if(a[j] == a[i] + 2 || a[j] == a[i] - 2 ){
                            found = 1;
                            System.out.println(a[j]);
                        }
                    }
                    if(found == 0 )
                        isTwin = 0;
                }
            }
        }
        return isTwin;
    }
    public static int isPrime( int n){
        if (n < 2)
            return 0;
        for (int i = 2; i <= n/2; i++){
            if ( n % i == 0){
                return 0;
            }
        }
        return 1;
    }
}
