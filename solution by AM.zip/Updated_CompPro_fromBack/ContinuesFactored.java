package Updated_CompPro_fromBack;

public class ContinuesFactored {
    public static void main(String[] args){
        int[] a ={6,60,120,90,24,99};
        for(int i : a)
            System.out.println(isContinuesF(i));
    }
    public static int isContinuesF(int n){
        for(int i = 2;i<n;i++){
            int num = n;
            int p = 1, index = i;
            while(num % index == 0){
                p *= index;
                num /= index;
                index++;
            }
            if(p == n) return 1;
        }
        return 0;
    }
}
