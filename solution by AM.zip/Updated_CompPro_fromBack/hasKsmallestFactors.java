package Updated_CompPro_fromBack;

public class hasKsmallestFactors {
    public static void main(String[ ] args){
        System.out.println(hasKSmaller(10,20));
        System.out.println(hasKSmaller(7,30));
        System.out.println(hasKSmaller(6,14));
        System.out.println(hasKSmaller(6,30));

    }
    public static int hasKSmaller(int k, int n){
        int result = 0; int u = 1, v = 1;
        for(int i = 1; i < k; i++){
            for(int j = 1; j < k; j++){
                if(i*j == n)
                    return 1;
            }
        }
        return 0;
    }
}
