package Updated_CompPro_fromBack;

public class MeeraArrayPage77 {
    public static void main(String[] args){
        int[][] a = {{-4,0,1,0,2},
                    {0,0,1,2},
                    {-1,0,0,8,0}};
        for(int[] i : a)
            System.out.println(isMeera(i));
    }
    public static int isMeera(int[] a){
        if(a == null)
            return 0;
        for(int i = 0; i < a.length; i ++){
            if(a[i] >= i)
                return 0;
        }
        return 1;
    }
}
