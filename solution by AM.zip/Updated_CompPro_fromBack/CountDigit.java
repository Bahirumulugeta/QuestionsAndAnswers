package Updated_CompPro_fromBack;

public class CountDigit {
    public static void main(String[] args){
        int[] a = {3212,33331,33331,3};
        int[] b = {1,3,6,3};
        for(int i = 0; i < a.length; i++)
            System.out.println(countD(a[i],b[i]));
    }
    public static int countD(int n , int digit){
        int c = 0;
        while(n > 0){
            int rem = n % 10;
            if(rem == digit)
                c ++;
            n = n / 10;
        }
        return c;
    }
}
