package Updated_CompPro_fromBack;

public class CubicPerfectArray {
    public static void main(String[] args){
        int[][] a = {{ 1, -8, -27, 8},{1,64,216,125},{3, 7, 21, 36}};
    for(int[] i : a)
        System.out.println(isCubic(i));
    }
    public static int isCubic(int [] a){
        boolean cubic = false;
        for(int i = 0; i < a.length; i++){
            if(a[i] < 0)
                a[i] = a[i] *(-1);
            int cube = 0;
            for(int j = 1; cube <= a[i]; j++){
                cube = j*j*j;
                if(cube == a[i])
                    cubic = true;
            }
            if(!cubic)
                return 0;
        }
        return 1;
    }
}
