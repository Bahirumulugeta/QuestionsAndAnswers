package Updated_CompPro_fromBack;

public class DaphneAray {
    public static void main(String[] args){
        int[][] a = {{4, 8, 6, 3, 2, 9, 8,11, 8, 13, 12, 12, 6},
                {2, 4, 6, 8, 6},
                {2, 8, 7, 10, -4, 6},
                {4,5,8}};
        for(int[] i : a)
            System.out.println(isDaphne(i));
    }
    public static int isDaphne(int[] a){
        int evenbeg = 0, evenlast = 0; boolean firstOdd = true, lastOdd = true;
        for(int i = 0, j = a.length-1; i < j+1; i++, j--){
            if(a[i] % 2 == 0 && firstOdd)
                evenbeg ++;
            else
                firstOdd = false;
            if(a[j] % 2 == 0 && lastOdd)
                evenlast ++;
            else
                lastOdd = false;

            if(!(firstOdd && lastOdd))
                break;
        }
        if(!(firstOdd || lastOdd) && (evenbeg == evenlast))
            return 1;
        return 0;
    }
}
