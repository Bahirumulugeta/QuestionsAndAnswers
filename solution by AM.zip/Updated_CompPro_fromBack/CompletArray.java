package Updated_CompPro_fromBack;

public class CompletArray {
    public static void main(String[] args){
        int[][] a = {{2,3,2,4,11,6,10,9,8},
                    {2,3,3,6},
                    {2,4,3,6}};
        for(int i[] : a)
            System.out.println(isComplete(i));
    }
    public static int isComplete(int[] a){
        if(a == null)
            return 0;
        int max = Integer.MIN_VALUE;
        for(int i = 0; i < a.length; i ++){
            if(a[i] <= 0)
                return 0;
            if(a[i] % 2 == 0 && max < a[i])
                max = a[i];
        }
        int temp = max - 2;
        while(temp > 0){
            int found = 0;
            for(int i = 0; i < a.length && found == 0; i++){
                if(temp == a[i])  found = 1;
            }
            if(found == 0)
                return 0;
            temp = temp -2;
        }
        return 1;
    }
}
