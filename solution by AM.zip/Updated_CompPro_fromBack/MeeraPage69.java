package Updated_CompPro_fromBack;

public class MeeraPage69 {
    public static void main(String[] args){
        int[][] a = { {-4, 0, 1, 0, 2, 1},{-8, 0, 0, 8, 0}, {-8, 0, 0, 2, 0}};
        for(int[] i :a)
            System.out.println(isMeera(i));
    }
    public static int isMeera(int[] a){
        int ismeera = 0, sum =0;
        for(int i = 0; i < a.length && ismeera == 0; i++){
            if(a[i] >= i)
                ismeera = 1;
            sum += a[i];
        }
        if(ismeera == 0 && sum == 0)
            return 1;
        return 0;
    }
}
