package Updated_CompPro_fromBack;

public class EqualArray {
    public static void main(String[] args){
        int[] a1 = { 1, 12, 1,9};
        int[] a2 = {1,9, 12, 9, 12, 1, 9};
        System.out.println(isEqual(a1,a2));
    }
    public static int isEqual(int[] a1, int[] a2){

        for(int i = 0; i < a1.length ; i++){
            int found = 0;
            for(int j = 0; j < a2.length && found ==0 ; j++){
                if(a1[i] == a2[j])
                    found = 1;
            }
            if(found == 0)
                return 0;
        }

        for(int i = 0; i < a2.length ; i++){
            int found = 0;
            for(int j = 0; j < a1.length && found == 0; j++){
                if(a2[i] == a1[j])
                    found = 1;
            }
            if(found == 0)
                return 0;
        }
        return 1;
    }
}
