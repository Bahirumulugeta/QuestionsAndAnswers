package Updated_CompPro_fromBack;

public class Hallow {
    public static void main(String[] args) {
        int[][] a = {{1, 2, 0, 0, 0, 3, 4},
                {1, 1, 1, 1, 0, 0, 0, 0, 0, 2, 1, 2, 18},
                {1, 2, 0, 0, 3, 4},
                {1, 2, 0, 0, 0, 3, 4, 5},
                {3, 8, 3, 0, 0, 0, 3, 3},
                {1, 2, 0, 0, 0, 3, 4, 0},
                {0, 1, 2, 0, 0, 0, 3, 4},
                {0, 0, 0}};
        for(int i[] : a)
          System.out.println(isHallow(i));
    }

    public static int isHallow(int[] a) {
        int zeroCount = 0, nonZeroB = 0, nonZeroE = 0;
        if (a.length < 3) return 0;

        for (int i = 0; i < a.length; i++) {
            if (a[i] != 0 && zeroCount == 0) nonZeroB++;
            else if (a[i] == 0 && nonZeroE == 0) zeroCount++;
            else if (a[i] != 0 && zeroCount > 0) nonZeroE++;
            else if (a[i] == 0 && nonZeroE > 0) return 0;
        }
        if (zeroCount >= 3 && nonZeroB == nonZeroE) return 1;
        return 0;
    }
}
