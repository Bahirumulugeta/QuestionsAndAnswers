package Updated_CompPro_fromBack;

public class BeanArray {
    public static void main(String[] args){
        int[][] a ={{21,3,7,9,11,4,6},
                    {13,4,4,4},
                    {10,5,5},
                    {0,6,8,10},
                    {3},
                    {8,5,-5,5,3}};
        for(int i[] : a)
            System.out.println(isBeanArray(i));
    }
    public static int isBeanArray(int[] a){
        if(a == null)
            return 0;
        int primeSum = 0;
        for(int i = 0; i < a.length; i++){
            if(isPrime(a[i]) == 1)
                primeSum += a[i];
        }
        if(a[0] == primeSum)
            return 1;
        return 0;
    }
    public static int isPrime( int n){
        if (n < 2)
            return 0;
        for (int i = 2; i <= n/2; i++){
            if ( n % i == 0){
                return 0;
            }
        }
        return 1;
    }
}
