package Updated_CompPro_fromBack;

public class OddValent {
    public static void main(String[] args) {
        int[][] a = {{9, 3, 4, 9, 1}, {3, 3, 3, 3}, {8, 8, 8, 4, 4, 7, 2}, {1, 2, 3, 4, 5}, {2, 2, 2, 4, 4}};
        for(int[] i : a)
            System.out.println(isOddV(i));
    }

    private static int isOddV(int[] a) {
        if (a.length == 0 || a == null)
            return 0;
        int containsOdd = 0;
        for (int i = 0; i < a.length; i++) {
            if (a[i] % 2 == 1)
                containsOdd = 1;
            int count = 0;
            for (int j = 0; j < a.length; j++) {
                if (a[i] == a[j])
                    count++;
            }
            if (count >= 2 && containsOdd == 1)
                return 1;
        }
        return 0;
    }
}
