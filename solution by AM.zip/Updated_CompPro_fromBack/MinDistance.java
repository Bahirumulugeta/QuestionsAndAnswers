package Updated_CompPro_fromBack;

public class MinDistance {
    public static void main(String[] args){
        System.out.println(minDistance(8));
    }
    public static int minDistance(int n){
       int minD = n - 1, divisor = 1;
       for(int i = 2; i <= n; i++){
           if(n % i == 0){
               if(minD > i - divisor)
                   minD = i - divisor;
               divisor = i;
           }
       }
        return minD;
    }
}
