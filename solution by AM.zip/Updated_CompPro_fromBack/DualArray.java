package Updated_CompPro_fromBack;

public class DualArray {
    public static void main(String[] args){
        int[][] a = {{1, 2, 1, 3, 3, 2},
                     {2, 5, 2, 5, 5},
                     {3, 1, 1, 2, 2}};
        for(int i[] : a)
            System.out.println(isDualArray(i));
    }
    public static int isDualArray(int[] a){
        if(a.length % 2 == 1)
            return 0;
        for(int i = 0; i < a.length; i++){
            int count = 0;
            for(int j=0; j < a.length && count < 2; j ++){
                if(a[i] == a[j])
                    count ++;
            }
            if(count != 2)
                return 0;
        }
        return 1;
    }
}
