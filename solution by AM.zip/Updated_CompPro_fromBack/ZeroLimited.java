package Updated_CompPro_fromBack;

public class ZeroLimited {
    public static void main(String[] args) {
        int[][] a = {{0, 0, 0, 0, 0},
                   {1, 0},
                   {0, 1},
                   {5},
                   {1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0},
                   {}};
        for(int[] i : a)
            System.out.println(isZeroLimited(i));
    }
    private static int isZeroLimited(int[] a){
        for(int i = 0; i < a.length; i ++){
            if(a[i] == 0 && i % 3 != 1)
                return 0;
            else if(a[i] != 0 && i % 3 == 1)
                return 0;
        }
        return 1;
    }
}
