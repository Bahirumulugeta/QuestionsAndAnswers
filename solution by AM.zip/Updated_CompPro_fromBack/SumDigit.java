package Updated_CompPro_fromBack;

public class SumDigit {
    public static void main(String[] args){
        int[] a = {3114,-6543,100,234,543};
        for(int i : a)
            System.out.println(sumDigit(i));
    }
    public static int sumDigit(int n){
        int digitSum = 0;
        int lastDigit = 0;
        if(n < 0)
            n *= -1;
        while(n > 0){
            lastDigit = n % 10;
            digitSum += lastDigit;
            n /= 10;
        }
        return digitSum;
    }
}
