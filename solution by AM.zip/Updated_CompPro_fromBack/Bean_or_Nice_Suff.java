package Updated_CompPro_fromBack;

public class Bean_or_Nice_Suff {
    public static void main(String[] args){
        int[] a = {2,3,4,10};
        System.out.println(isBeanArray(a));
    }
    public static int isBeanArray(int[] a){
        int isBean = 1;
        for (int i= 0; i < a.length && isBean == 1;i++){
            int exist = 0;
            for (int j = 0; j < a.length && exist == 0; j ++){
                if (a[i] == a[j]+1 || a[i]  == a[j]-1){
                    exist = 1;
                }
            }
            if (exist == 0)
               isBean = 0;
        }
        return isBean;
    }
}
