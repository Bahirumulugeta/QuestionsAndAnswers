package Updated_CompPro_fromBack;

public class BunkerAray_page65 {
    public static void main(String[] args){
        int[][] a = {{4, 9, 6, 7, 3},{4,9,6,15,21},{1},{3,5,12}};
        for(int[] i : a)
            System.out.println(isBunk(i));
    }
    public static int isBunk(int [] a){
        if(a.length < 2)
                return 0;
        for (int i = 0; i < a.length-1 ; i ++){
            if(a[i] % 2 == 1 && isPrime(a[i+1]) == 1)
                return 1;
        }
        return 0;
    }
    public static int isPrime( int n){
        if (n < 2)
            return 0;
        for (int i = 2; i <= n/2; i++){
            if ( n % i == 0){
                return 0;
            }
        }
        return 1;
    }
}

