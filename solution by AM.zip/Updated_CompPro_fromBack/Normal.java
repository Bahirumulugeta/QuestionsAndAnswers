package Updated_CompPro_fromBack;

public class Normal {
    public static void main(String[] args){
        int[] a = { 1, 2, 3, 4, 5, 6, 7, 8, 9};
        for (int i : a)
            System.out.println(isNormal(i));
    }
    public static int isNormal(int n){
        for (int i = 2; i < n; i++){
            if (n % i == 0 && i % 2 == 1)
                return 0;
        }
        return 1;
    }
}
