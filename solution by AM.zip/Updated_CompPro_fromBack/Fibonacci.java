package Updated_CompPro_fromBack;

public class Fibonacci {
    public static void main(String[] args){
        System.out.println(isFibinacci(4));
    }
    public static int isFibinacci(int n){
        int first = 1, second = 1, current = 0;
        if (n < 0)
            return 0;
        if (n == 1)
            return 1;
        do {
            current = first + second;
            first = second;
            second = current;

            if (current == n)
                return 1;
        }while (current <= n );
        return 0;
    }
}
