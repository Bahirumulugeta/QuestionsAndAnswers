package Updated_CompPro_fromBack;

public class FactorTwoCount {
    public static void main(String[] args){
        System.out.println(factorTwo(62));
    }
    public static int factorTwo(int n){
       // boolean check2= true;
        int countFactor2 = 0;
        while(n > 0){
            if(n % 2 == 0)
                countFactor2 ++;
            else break;
            n = n /2;
        }
        return countFactor2;
    }
}
