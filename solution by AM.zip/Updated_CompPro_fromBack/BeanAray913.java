package Updated_CompPro_fromBack;

public class BeanAray913 {
    public static void main(String[] args){
        int[][] a = {{1, 2, 3, 9, 6, 13},
                    {3, 4, 6, 7, 13, 15},
                    {1, 2, 3, 4, 10, 11, 12},
                    { 9, 6, 18},
                    {4, 16},
                    {3, 6, 9, 5, 7, 13, 6, 17}};
        for (int[] i : a)
            System.out.println(isBean(i));
    }
    public static int isBean(int[] a){
        int has9 = 0, has13 = 0, has7 = 0, has16 = 0;
        if (a == null)
            return 0;
        for (int i = 0; i < a.length; i ++){
            if (a[i] == 9)
                has9 = 1;
            else if (a[i] == 7)
                has7 = 1;
            else if (a[i] == 13)
                has13 = 1;
            else if (a[i] == 16) {
                has16 = 1;
                if (has7 == 1)
                    return 0;
            }
        }
        if (has7 == 1 && has16 == 1 || has9 == 1 && has13 == 0)
            return 0;
        return 1;
    }
}
