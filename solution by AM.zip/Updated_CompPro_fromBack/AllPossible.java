package Updated_CompPro_fromBack;

public class AllPossible {
    public static void main(String[] args){
        int[][] a = {{1, 2, 0, 3},
                    {3, 2, 1, 0},
                    {1, 2, 4, 3},
                    {0, 2, 3},
                    {0},
                    {}};
        for(int[] i : a)
            System.out.println(isAllPossible(i));
    }
    private static int isAllPossible(int[] a){
        if (a.length == 0)
            return 0;
        int allP = 1;
        for (int i = 0; i < a.length && allP == 1; i++) {
            int found = 0;
            for(int j = 0; j < a.length && found == 0; j ++)
                if(i == a[j]) found = 1;
            if(found == 0)
                allP = 0;
        }
        return allP;
    }
}
