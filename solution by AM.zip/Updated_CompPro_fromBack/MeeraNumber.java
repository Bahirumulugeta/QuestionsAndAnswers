package Updated_CompPro_fromBack;

public class MeeraNumber {
    public static void main(String[] args){
        int[] a = {6,30,21};
        for (int i : a)
            System.out.println(isMeeraN(i));
    }
    public static int isMeeraN(int n){
        int trivFactor = 0;
        for (int i = 2; i <= n/2; i++){
            if (n % i == 0)
                trivFactor ++;
        }
        if (n % trivFactor == 0)
            return 1;
        return 0;
    }
}
