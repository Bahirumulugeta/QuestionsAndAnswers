package Updated_CompPro_fromBack;

public class WaveArray {
    public static void main(String[] args){
        int[][] a = { {7, 2, 9, 10, 5},
                   {4, 11, 12, 1, 6},
                   {1, 0, 5},
                    {2, 6, 3, 4},
                   {2}};
        for (int[] i : a){
            System.out.println(isWave(i));
        }
    }
    public static int isWave (int [ ] a){
        if (a == null)
            return 0;
        for (int i = 0; i < a.length-1; i++){
            if (a.length >=2){
                if (a[i] % 2 == 0 && a[i+1] % 2 == 0 || a[i] % 2 == 1 && a[i+1] % 2 ==1)
                    return 0;
            }
        }
        return 1;
    }
}
