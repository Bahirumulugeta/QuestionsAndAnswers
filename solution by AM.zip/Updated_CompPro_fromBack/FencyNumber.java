package Updated_CompPro_fromBack;

public class FencyNumber {
    public static void main(String[] args){
        int[] a = {1,5,7,15,17,61};
        for(int i : a)
            System.out.println(isFency(i));
    }
    public static int isFency(int n){
        int first = 1, second = 1;
        int current = 1;
        while(current <= n){
            if(current == n)
                return 1;
            current =2*first + 3*second;
            first = second;
            second = current;
        }
        return 0;
    }
}
