package Updated_CompPro_fromBack;

public class FactorEqual {
    public static void main(String[] args){
        System.out.println(isFEqual(10,6));
    }
    public static int isFEqual(int m , int n){
        if( m == n) return 1;
        int great = 0;
        if(n > m)
            great = n;
        else great = m;
        int countFM = 0 , countFN = 0;
        for(int i = 1; i <= great; i ++ ){
            if(m % i == 0)
                countFM ++;
            if(n % i == 0)
                countFN ++;
        }
        if(countFM == countFN)
            return 1;
        return 0;
    }
}
