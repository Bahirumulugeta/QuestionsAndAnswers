package Updated_CompPro_fromBack;

public class BeanArrayPage77 {
    public static void main(String[] args){
        int[][] a = {{4,9,8},{2,2,5,11,23},{7,7,3,6},{0},{3,8,4}};
        for(int[] i : a)
            System.out.println(isBean(i));
    }
    public static int isBean(int [] a){
        int isBean = 1;
        for(int i = 0; i < a.length && isBean == 1; i ++){
            int current = a[i];
            int found = 0;
            for(int j = 0; j < a.length && found == 0; j++){
                if(a[j] == current*2 || a[j] == current*2+1 || a[j] == current/2)
                    found = 1;
            }
            if( found == 0)
                isBean = 0;
        }
        return isBean;
    }
}
