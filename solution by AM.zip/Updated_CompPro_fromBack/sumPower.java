package Updated_CompPro_fromBack;

public class sumPower {
    public static void main(String[] args){
        int[] a = {8,8,8,8};
        System.out.println(isSumPower(a));
    }
    public static boolean isSumPower(int[] a){
        int sum = 0, power = 1;

        for (int i = 0; i < a.length; i++){
            sum += a[i];
        }
//        for (int i = 1 ; power < sum; i++){
//            power *= 2;
//        }
//        return (sum == power);
        while(sum >= 2){
            if(sum % 2 == 1)
                return false;
            sum /= 2;
        }
        return true;
    }
}
