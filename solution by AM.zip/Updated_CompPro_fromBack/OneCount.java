package Updated_CompPro_fromBack;

public class OneCount {
    public static void main(String[] args){
        System.out.println(one_count(5));
    }
    public static int one_count(int n){
        int count = 0;
        while(n > 0){
            if(n % 2 ==1)
                count++;
            n = n /2;
        }
        return count;
    }
}
