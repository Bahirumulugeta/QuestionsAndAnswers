package Updated_CompPro_fromBack;

public class TripleArray {
    public static void main(String[] args){
        int[][] a ={ {3, 1, 2, 1, 3, 1, 3, 2, 2},{2,5,2,5,5,2,5},{3,1,1,1},{2,1,3,1,2,3,3,2,1} };
        for(int[] i : a)
            System.out.println(isTriple(i));
    }
    public static int isTriple(int[] a){
        if(a.length < 3)
            return 0;
        for(int i = 0; i <a.length; i++){
            int current = a[i];
            int count = 0;
            for(int j = 0; j < a.length && count <= 3; j++){
                if (a[j] == current)
                    count ++;
            }
            if(count != 3)
                return 0;
        }
        return 1;
    }
}
