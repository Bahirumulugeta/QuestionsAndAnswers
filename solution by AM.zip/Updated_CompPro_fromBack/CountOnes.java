package Updated_CompPro_fromBack;

public class CountOnes {
    public static void main(String[] args){
        int[] a = {6,5,7,15,20};
        for (int i = 0; i < a.length; i++) {
            System.out.println(countOnes(a[i]));
        }
    }
    public static int countOnes(int n){
        int countOne = 0;
        while(n > 0){
            int re = n % 2;
            n = n /2;
            if(re == 1)
                countOne++;
        }
        return countOne;
    }
}
