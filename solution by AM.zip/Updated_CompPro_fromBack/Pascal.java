package Updated_CompPro_fromBack;

public class Pascal {
    public static void main(String[] args){
        int [] a = {2,6,10,11,21,15};
        for (int i : a)
            System.out.println(isPascal(i));
     }
    public static int isPascal (int n){
        int sum = 0; int i = 1;
        while(sum <= n){
            sum += i;
            if (sum == n)
                return 1;
            i++;
        }
        return 0;
    }
}
