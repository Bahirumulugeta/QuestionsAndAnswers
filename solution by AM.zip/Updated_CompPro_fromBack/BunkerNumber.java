package Updated_CompPro_fromBack;

public class BunkerNumber {
    public static void main(String[] args){
        int[] a = {11,22,8,1,2,3,4};
        for(int i : a)
            System.out.println(isBunker(i));
    }
    public static int isBunker(int n){
        int current = 1;
        int diff = 0;
        for(int i = 1; current <= n; i ++){
            if(current == n)
                return 1;
            current += diff;
            diff ++;
        }
        return 0;
    }
}
