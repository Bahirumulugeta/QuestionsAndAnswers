package MUMsample;

public class Equiliblrium {
    public static void main(String[] args) {
        int[][] a = {{1, 8, 3, 7, 10, 2},
                {1, 5, 3, 1, 1, 1, 1, 1, 1},
                {2, 1, 1, 1, 2, 1, 7},
                {1, 2, 3},
                {3, 4, 5, 10},
                {1, 2, 10, 3, 4}};
        for(int[] i : a){
            System.out.println(a6(i));
        }
    }

    static int a6(int[] a) {
        if (a.length < 3) return -1;
        int i = 0;
        int j = a.length - 1;
        int idx = 1;
        int leftSum = a[i];
        int rightSum = a[j];
        for (int k = 1; k < a.length - 2; k++) {
            if (leftSum < rightSum) {
                i++;
                leftSum += a[i];
                idx = i + 1;
            } else {
                j--;
                rightSum += a[j];
                idx = j - 1;
            }
        }
        if (leftSum == rightSum)
            return idx;
        else
            return -1;
    }
}
