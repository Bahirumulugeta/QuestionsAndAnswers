package MUM_Q1;

public class Normal {
    public static void main(String[] args) {
        int[] a = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
        for (int i : a)
        System.out.println(isNormal(i));
    }
    public static int isNormal(int n){

        int isNormal = 1;
        for (int i = 3; i < n && isNormal ==1; i+=2) {
            if (n % i == 0) {
                isNormal = 0;
            }
        }
     return isNormal;
    }
}
