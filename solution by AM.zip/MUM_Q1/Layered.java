package MUM_Q1;

public class Layered {
    public static void main(String[] args){
        int[][] a= {{1, 1, 2, 2, 2, 3, 3},
            {3, 3, 3, 3, 3, 3, 3},
            {1, 2, 2, 2, 3, 3},
            {2, 2, 2, 3, 3, 1, 1},
            {2},
            {}};
        for (int i[] : a)
            System.out.println(isLayered(i));
    }
    public static int isLayered(int[ ] a){
        int isLayered = 1;
        if (a.length < 2) isLayered = 0;
        int  count = 0;
        for (int i = 0; i < a.length-1 && isLayered==1; i++){
            count++;
            if (a[i] != a[i + 1]){
                if (count < 2)
                    isLayered = 0;
                count = 0;
            }
            if(a[i] > a[i + 1]){
                isLayered = 0;
            }
        }
        return isLayered;
    }
}
