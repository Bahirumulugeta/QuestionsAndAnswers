package MUM_Q1;

public class Comulative {
    public static void main(String[] args){
        int a[][] = {{3, 3, 6, 12, 24},
                     {0,0,0,0,0,0},
                     {1,1,1,1,1,1,1,1},
                     {1},
                     {-3, -3, -6, -12, -24},
                     {-3, -3, 6, 12, 24}};
        for (int[] i : a)
         System.out.println(isComulative(i));
    }
    private static int isComulative(int[] a){
        if (a.length < 2 )
            return 0;
        int comm = 0;
        for (int i = 1; i < a.length; i++){
            comm += a[i-1];
            if (comm != a[i])
                return 0;
        }
        return 1;
    }
}
