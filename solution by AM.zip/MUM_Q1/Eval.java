package MUM_Q1;

public class Eval {
    public static void main(String[] args){
        int[] a = {0,1};
        double x = 10;
        System.out.println(eval(x,a));
    }
    public static double eval(double x, int[ ] a){
        double pol= 0; // Additive identity
        for (int i = 0; i < a.length; i++){
            pol += a[i]*(Math.pow(x , i));
        }
        return pol;
    }
}
