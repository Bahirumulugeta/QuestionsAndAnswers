package MUM_Q1;

public class Dual {
    public static void main(String[] args){
        int i[][] = {{1, 2, 3, 0},// 1 (because 1+2 == 3+0 == 3)
                     {1, 2, 2, 1, 3, 0},// 1 (because 1+2 == 2+1 == 3+0 == 3)
                     {1, 1, 2, 2},// 0 (because 1+1 == 2 != 2+2)
                     {1, 2, 1},// 0 (because array does not have an even number of elements)
                     {}};
        for (int a[] : i)
            System.out.println(isDual(a));
    }
    public static int isDual(int[] a){
        if (a.length % 2 != 0)
            return 0;
        if (a.length == 0)
            return 1;
        int sum = a[0] + a[1];
        for (int i = 0; i < a.length; i+=2){
            if (sum != a[i]+a[i+1])
                return 0;
        }
        return 1;
    }
}
