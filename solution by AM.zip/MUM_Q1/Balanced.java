package MUM_Q1;

public class Balanced {
    public static void main(String[] args){
        int a[][] = {{2, 3, 6, 7},
                      {6, 3, 2, 7},
                      {6, 7, 2, 3, 12},
                      {6, 7, 2, 3, 14, 95},
                      {7, 15, 2, 3},
                      {16, 6, 2, 3},
                      {2},
                      {3},
                      {}};
        for (int[] i : a){
            System.out.println(isBalanced(i));
        }
    }
    public static int isBalanced(int[] a){
        for (int i = 0; i < a.length; i++){
            // check for even index
           if(i % 2 == 0){
               if(a[i] % 2 != 0)
                   return 0;
           }
            // check for odd index;
           else{
                if (a[i] % 2 == 0)
                    return 0;
            }
        }
        return 1;
    }
}
