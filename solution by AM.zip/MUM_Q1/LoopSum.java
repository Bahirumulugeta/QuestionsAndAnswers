package MUM_Q1;

public class LoopSum {
    public static void main(String[] args){
        int[] a = {1, 4, 5, 6};
            int n = 5;
            System.out.println(loopSum(a,n));
    }
    public static int loopSum(int[ ] a, int n){
        int sum = 0, index;
        for (int i = 0; i < n; i++){
            index = i % a.length;
            sum += a[index];
        }
        return sum;
    }
}
