package MUM_Q1;

public class Infinite {
    public static void main(String[] args){
        int[][] a = {{1, 2, -1, 5},
        {1, 2, 4, -1},
        {5, 3, 4, -1, 1, 2},
                {3},{3,2,3,1},
                {0},
        {-1}};
        for (int[] i : a)
            System.out.println(isInfinite(i));
    }
    public static int isInfinite(int[ ] a){
        int i = 0, c = 0;
        while (c < a.length){
            if (a[i] == -1)
                return -1;
            else if (a[i] < -1 || a[i] >= a.length)
                return 1;
            else{
                 i = a[c];
                }
            c++;
        }
        return 0;
    }
}
