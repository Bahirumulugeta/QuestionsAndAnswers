package MUM_Q1;

public class Centered {
    public static void main(String[] args){
        int a[][] = {{1, 2, 3, 4, 5},
                     {3, 2, 1, 4, 5},
                     {3, 2, 1, 4, 1},
                     {3, 2, 1, 1, 4, 6},
                     {},
                     {1}};
        for (int[] i : a){
            System.out.println(isCentered(i));
        }
    }
    public static int isCentered(int a[]) {
        if (a.length % 2 == 0 || a == null)
            return 0;
        int middleE = a[a.length / 2];
        int midIndex = a.length / 2;
        for (int i = 0; i < a.length; i++) {
            if(i != midIndex && a[i] <= middleE)
                return 0;
        }
        return 1;
    }
}
